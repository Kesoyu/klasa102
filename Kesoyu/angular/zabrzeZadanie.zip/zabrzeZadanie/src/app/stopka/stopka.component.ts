import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stopka',
  templateUrl: './stopka.component.html',
  styleUrls: ['./stopka.component.css']
})
export class StopkaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
