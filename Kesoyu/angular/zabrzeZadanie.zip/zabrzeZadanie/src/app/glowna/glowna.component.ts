import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-glowna',
  templateUrl: './glowna.component.html',
  styleUrls: ['./glowna.component.css']
})
export class GlownaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
