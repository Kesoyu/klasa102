import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-atrakcje',
  templateUrl: './atrakcje.component.html',
  styleUrls: ['./atrakcje.component.css']
})
export class AtrakcjeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
