import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-jeden',
  templateUrl: './jeden.component.html',
  styleUrls: ['./jeden.component.css']
})
export class JedenComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
