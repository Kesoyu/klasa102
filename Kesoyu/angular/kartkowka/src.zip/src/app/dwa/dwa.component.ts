import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dwa',
  templateUrl: './dwa.component.html',
  styleUrls: ['./dwa.component.css']
})
export class DwaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
