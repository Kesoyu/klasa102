import { Samochod } from "./samochod";

export const SAMOCHODY:Samochod[] = 
[
    new Samochod("Makigai MaiMai P126", "assets/img/maimai.jpg"),
    new Samochod("Quadra Turbo-R V-Tech", "assets/img/quadra.jpg"),
    new Samochod('Mizutani Shion "Coyote"', "assets/img/shion.jpg"),
    new Samochod("Rayfield Aerondight", "assets/img/aerondight.jpg")
]